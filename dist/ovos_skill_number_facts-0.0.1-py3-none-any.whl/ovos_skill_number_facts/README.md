## Numbers

Facts about numbers

## Description

facts about numbers, math, years and dates from http://numbersapi.com

a good example on how to use extract date and extract numbers functions

## Examples
 * "random math fact"
 * "random number trivia"
 * "random date curiosity"
 * "random year trivia"
 * "fact about number 666"
 * "math fact about number 5"
 * "curiosity about year 1992"
 * "trivia about tomorrow"
 * "trivia about next week"
 * "fact about yesterday"
 * "curiosity about march 13"

## Credits
JarbasAI

